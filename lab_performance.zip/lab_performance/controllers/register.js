var express 	= require('express');
var router 		= express.Router();
var userModel   = require.main.require('./models/user-model');


router.get('*', function(req, res, next){
	if(req.cookies['username'] == null){
		res.render('register/index');
	}else{
		res.redirect('/home');
	}
});

router.post('/', function(req, res){
	
	var user = {
		name: req.body.name,
		mail: req.body.mail,
	};

	userModel.insert(user, function(status){
		if(status){
			res.redirect('/login');
			res.send('Registered');
		}else{
			res.send("Couldn't Register");
			res.redirect('/register');
		}
	});
})

module.exports = router;

